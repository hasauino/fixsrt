# fixsrt
A python script to fix srt file exported from sonix ai with double lines encoded with a special string
